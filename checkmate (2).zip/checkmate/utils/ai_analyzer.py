"""
AI 분석 로직을 담당하는 모듈

이 모듈은 LangChain과 Google Gemini를 사용해서 수행평가 초안을 분석하고
평가 조건에 대한 충족 여부를 판단하는 기능을 제공합니다.
고등학생도 이해할 수 있도록 간단한 설명을 포함했습니다.
"""

import streamlit as st
import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage, SystemMessage
import json
import re
from .prompts import SYSTEM_PROMPT, create_human_prompt

class PerformanceAnalyzer:
    """
    수행평가 분석을 담당하는 클래스
    
    이 클래스는 AI를 사용해서 학생의 수행평가 초안이 
    주어진 조건들을 얼마나 잘 만족하는지 분석합니다.
    """
    
    def __init__(self):
        """
        AI 분석기를 초기화하는 함수
        
        Google Gemini API 키를 확인하고 AI 모델을 설정합니다.
        """
        # Google Gemini API 키 확인
        api_key = os.getenv('GOOGLE_API_KEY')
        if not api_key:
            st.error("Google Gemini API 키가 설정되지 않았습니다. .env 파일에 GOOGLE_API_KEY를 추가해주세요.")
            self.llm = None
            return
        
        try:
            # AI 모델 설정 (Gemini 2.5 Pro 사용)
            self.llm = ChatGoogleGenerativeAI(
                model="gemini-2.0-flash-exp",
                temperature=0.1,  # 일관된 결과를 위해 낮은 온도 설정
                google_api_key=api_key
            )
        except Exception as e:
            st.error(f"AI 모델 초기화 중 오류가 발생했습니다: {str(e)}")
            self.llm = None
    
    def analyze_performance(self, conditions, draft):
        """
        수행평가 초안을 분석하는 메인 함수
        
        Args:
            conditions (str): 수행평가 요구조건
            draft (str): 수행평가 초안
            
        Returns:
            dict: 분석 결과 (체크리스트, 점수, 피드백 등)
        """
        # LLM이 초기화되지 않았는지 확인
        if self.llm is None:
            st.error("AI 모델이 초기화되지 않았습니다. API 키를 확인해주세요.")
            return self._create_error_result()
        
        try:
            # 분석을 위한 프롬프트 생성
            prompt = self._create_analysis_prompt(conditions, draft)
            
            # AI에게 분석 요청
            response = self.llm.invoke(prompt)
            
            # 응답을 JSON 형태로 파싱
            result = self._parse_analysis_response(response.content)
            
            return result
            
        except Exception as e:
            st.error(f"AI 분석 중 오류가 발생했습니다: {str(e)}")
            return self._create_error_result()
    
    def _create_analysis_prompt(self, conditions, draft):
        """
        AI 분석을 위한 프롬프트를 생성하는 함수
        
        프롬프트는 AI가 수행평가를 분석할 때 따라야 할 지침을 담고 있습니다.
        
        Args:
            conditions (str): 수행평가 요구조건
            draft (str): 수행평가 초안
            
        Returns:
            list: AI 프롬프트 메시지 리스트
        """
        system_message = SystemMessage(content=SYSTEM_PROMPT)
        human_message = HumanMessage(content=create_human_prompt(conditions, draft))
        
        return [system_message, human_message]
    
    def _parse_analysis_response(self, response_text):
        """
        AI 응답을 파싱하는 함수
        
        AI가 보낸 텍스트를 JSON 형태로 변환해서 
        프로그램에서 사용할 수 있는 형태로 만듭니다.
        
        Args:
            response_text (str): AI 응답 텍스트
            
        Returns:
            dict: 파싱된 분석 결과
        """
        try:
            # JSON 부분만 추출 (```json과 ``` 사이의 내용)
            json_match = re.search(r'```json\s*(.*?)\s*```', response_text, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                # JSON 블록이 없으면 전체 텍스트를 JSON으로 시도
                json_str = response_text
            
            # JSON 파싱
            result = json.loads(json_str)
            return result
            
        except json.JSONDecodeError:
            st.error("AI 응답을 파싱하는 중 오류가 발생했습니다.")
            return self._create_error_result()
    
    def _create_error_result(self):
        """
        오류 발생 시 기본 결과를 생성하는 함수
        
        Returns:
            dict: 기본 오류 결과
        """
        return {
            "checklist": [],
            "scoring": {
                "content_fidelity": {"max_score": 40, "score": 0, "evaluation": "분석 오류"},
                "condition_fulfillment": {"max_score": 30, "score": 0, "evaluation": "분석 오류"},
                "logical_composition": {"max_score": 20, "score": 0, "evaluation": "분석 오류"},
                "grammar_expression": {"max_score": 10, "score": 0, "evaluation": "분석 오류"}
            },
            "total_score": 0,
            "max_total_score": 100,
            "improvement_suggestions": ["분석 중 오류가 발생했습니다. 다시 시도해주세요."]
        }
