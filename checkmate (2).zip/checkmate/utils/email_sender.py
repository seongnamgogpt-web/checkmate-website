"""
이메일 공유 기능을 담당하는 모듈

이 모듈은 분석 결과를 이메일로 공유하는 기능을 제공합니다.
고등학생도 이해할 수 있도록 간단한 설명을 포함했습니다.
"""

import streamlit as st
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

class EmailSender:
    """
    이메일 전송을 담당하는 클래스
    
    이 클래스는 수행평가 분석 결과를 이메일로 전송하는 기능을 제공합니다.
    """
    
    def __init__(self):
        """
        이메일 발송기를 초기화하는 함수
        
        이메일 설정을 확인하고 준비합니다.
        """
        # 이메일 설정 확인 (실제 사용 시에는 환경 변수로 설정)
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        
        # 실제 사용 시에는 환경 변수에서 가져와야 합니다
        # self.email = os.getenv('EMAIL_ADDRESS')
        # self.password = os.getenv('EMAIL_PASSWORD')
    
    def create_report_email(self, analysis_result, recipient_email):
        """
        분석 결과를 포함한 이메일을 생성하는 함수
        
        Args:
            analysis_result (dict): AI 분석 결과
            recipient_email (str): 받는 사람 이메일 주소
            
        Returns:
            str: 생성된 이메일 내용
        """
        # 이메일 제목
        subject = "Check Mate - 수행평가 분석 결과"
        
        # 이메일 본문 생성
        body = self._create_email_body(analysis_result)
        
        return subject, body
    
    def _create_email_body(self, analysis_result):
        """
        이메일 본문을 생성하는 함수
        
        분석 결과를 보기 좋게 정리해서 이메일 본문으로 만듭니다.
        
        Args:
            analysis_result (dict): AI 분석 결과
            
        Returns:
            str: 이메일 본문
        """
        body = """
안녕하세요!

Check Mate를 통해 수행평가 분석이 완료되었습니다.

📊 분석 결과 요약
================

🎯 총점: {total_score}점 / {max_score}점

📋 조건별 충족 여부
==================
""".format(
            total_score=analysis_result.get('total_score', 0),
            max_score=analysis_result.get('max_total_score', 100)
        )
        
        # 체크리스트 추가
        checklist = analysis_result.get('checklist', [])
        for item in checklist:
            status = "✅ 충족" if item.get('fulfilled', False) else "❌ 미충족"
            body += f"""
{status} - {item.get('condition_number', '조건')}
   내용: {item.get('content', '')}
   비고: {item.get('remarks', '')}
"""
        
        # 점수 세부사항 추가
        body += """
📈 세부 점수
===========
"""
        scoring = analysis_result.get('scoring', {})
        for category, details in scoring.items():
            category_name = self._get_category_name(category)
            score = details.get('score', 0)
            max_score = details.get('max_score', 0)
            evaluation = details.get('evaluation', '')
            
            body += f"""
{category_name}: {score}점 / {max_score}점
   평가: {evaluation}
"""
        
        # 개선 제안 추가
        suggestions = analysis_result.get('improvement_suggestions', [])
        if suggestions:
            body += """
💡 개선 제안
===========
"""
            for i, suggestion in enumerate(suggestions, 1):
                body += f"{i}. {suggestion}\n"
        
        body += """
---
Check Mate로 더 나은 수행평가를 작성하세요!
감사합니다.
"""
        
        return body
    
    def _get_category_name(self, category):
        """
        카테고리 영문명을 한글명으로 변환하는 함수
        
        Args:
            category (str): 카테고리 영문명
            
        Returns:
            str: 카테고리 한글명
        """
        category_names = {
            'content_fidelity': '내용 충실도',
            'condition_fulfillment': '조건 충족도',
            'logical_composition': '논리적 구성',
            'grammar_expression': '문법·표현력'
        }
        
        return category_names.get(category, category)
    
    def send_email(self, recipient_email, subject, body):
        """
        이메일을 전송하는 함수
        
        실제 이메일 전송을 위해서는 SMTP 설정이 필요합니다.
        현재는 시연용으로 성공 메시지만 표시합니다.
        
        Args:
            recipient_email (str): 받는 사람 이메일 주소
            subject (str): 이메일 제목
            body (str): 이메일 본문
            
        Returns:
            bool: 전송 성공 여부
        """
        try:
            # 실제 이메일 전송을 위한 코드 (현재는 주석 처리)
            """
            msg = MIMEMultipart()
            msg['From'] = self.email
            msg['To'] = recipient_email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.email, self.password)
            
            text = msg.as_string()
            server.sendmail(self.email, recipient_email, text)
            server.quit()
            """
            
            # 시연용 성공 메시지
            st.success(f"분석 결과가 {recipient_email}로 성공적으로 전송되었습니다!")
            st.info("실제 이메일 전송을 위해서는 SMTP 설정이 필요합니다.")
            
            return True
            
        except Exception as e:
            st.error(f"이메일 전송 중 오류가 발생했습니다: {str(e)}")
            return False
    
    def send_analysis_report(self, analysis_result, recipient_email):
        """
        분석 결과를 이메일로 전송하는 메인 함수
        
        Args:
            analysis_result (dict): AI 분석 결과
            recipient_email (str): 받는 사람 이메일 주소
            
        Returns:
            bool: 전송 성공 여부
        """
        # 이메일 생성
        subject, body = self.create_report_email(analysis_result, recipient_email)
        
        # 이메일 전송
        return self.send_email(recipient_email, subject, body)
