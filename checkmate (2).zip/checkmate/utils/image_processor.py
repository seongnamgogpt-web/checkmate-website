"""
이미지 처리 및 OCR 기능을 담당하는 모듈

이 모듈은 사용자가 업로드한 이미지에서 텍스트를 추출하는 기능을 제공합니다.
고등학생도 이해할 수 있도록 간단한 설명을 포함했습니다.
"""

import streamlit as st
from PIL import Image
import pytesseract
import io

def extract_text_from_image(uploaded_file):
    """
    업로드된 이미지에서 텍스트를 추출하는 함수
    
    이 함수는 OCR(광학 문자 인식) 기술을 사용해서 
    이미지에 있는 글자를 컴퓨터가 읽을 수 있는 텍스트로 변환합니다.
    
    Args:
        uploaded_file: Streamlit에서 업로드된 파일 객체
        
    Returns:
        str: 추출된 텍스트
    """
    try:
        # 이미지 파일을 PIL Image 객체로 변환
        image = Image.open(uploaded_file)
        
        # OCR을 사용해서 이미지에서 텍스트 추출
        # pytesseract는 Google에서 만든 OCR 엔진입니다
        extracted_text = pytesseract.image_to_string(image, lang='kor+eng')
        
        return extracted_text.strip()
    
    except Exception as e:
        st.error(f"이미지에서 텍스트를 추출하는 중 오류가 발생했습니다: {str(e)}")
        return ""

def process_uploaded_file(uploaded_file):
    """
    업로드된 파일을 처리하는 함수
    
    파일이 이미지인지 텍스트 파일인지 확인하고,
    적절한 방법으로 텍스트를 추출합니다.
    
    Args:
        uploaded_file: Streamlit에서 업로드된 파일 객체
        
    Returns:
        str: 추출된 텍스트
    """
    if uploaded_file is None:
        return ""
    
    # 파일 확장자 확인
    file_extension = uploaded_file.name.lower()
    
    # 이미지 파일인 경우 OCR 사용
    if file_extension.endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
        return extract_text_from_image(uploaded_file)
    
    # 텍스트 파일인 경우 직접 읽기
    elif file_extension.endswith(('.txt', '.md')):
        try:
            # 파일 내용을 UTF-8로 읽기
            content = uploaded_file.read().decode('utf-8')
            return content
        except Exception as e:
            st.error(f"텍스트 파일을 읽는 중 오류가 발생했습니다: {str(e)}")
            return ""
    
    else:
        st.error("지원하지 않는 파일 형식입니다. 이미지(.png, .jpg 등) 또는 텍스트 파일(.txt)을 업로드해주세요.")
        return ""
